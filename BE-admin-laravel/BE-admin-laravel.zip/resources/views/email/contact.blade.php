<h2>Thông tin liên hệ của khách hàng :</h2>
<p><strong>Họ tên:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Số điện thoại:</strong> {{ $phone }}</p>
<p><strong>Nội dung:</strong><br>{{ $bodyMessage }}</p>